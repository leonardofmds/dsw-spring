(function() {
    var app = angular.module('projeto', [
        'projeto.controllers',
        'projeto.directives',
    ]);
})();
