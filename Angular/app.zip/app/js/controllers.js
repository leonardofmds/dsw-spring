(function() {
    var app = angular.module('projeto.controllers', []);

    app.controller('MainController', function($scope) {

        $scope.valor = "Qualquer valor";

    });

})();


