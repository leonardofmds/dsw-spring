(function() {
    var app = angular.module('projeto.directives', []);

    app.directive('umItem', function() {
        // Aqui estará o código do componente
    });

})();


